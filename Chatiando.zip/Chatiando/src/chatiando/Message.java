/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatiando;

//===============================================================
// Mensaje
//===============================================================
import java.io.*;

public class Message implements Serializable {

public String name;
public String text;

public Message(String name, String text) {

    this.name = name;

    this.text = text;
}
}
