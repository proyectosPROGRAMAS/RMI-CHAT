/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatiando;

//===============================================================
// Servidor Chat
//===============================================================
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

public class ChatServer extends UnicastRemoteObject implements IChatServer {

    Hashtable<String, IChatClient> chatters = new Hashtable<String, IChatClient>();

    public ChatServer() throws RemoteException {}

    public synchronized void login(String name, IChatClient nc) throws RemoteException {
chatters.put(name,nc);

Enumeration entChater = chatters.elements();

while( entChater.hasMoreElements() ){

    ((IChatClient) entChater.nextElement()).receiveEnter(name);
}

System.out.println("Client " + name + " has logged in");
}

    public synchronized void logout(String name) throws RemoteException {

        System.out.println("Client " + name + " has logged out");

        Enumeration entChater = chatters.elements();

        while( entChater.hasMoreElements()) {

            ((IChatClient) entChater.nextElement()).receiveExit(name);

        }

        chatters.remove(name);
}
    

    public synchronized void send(Message message) throws RemoteException {

        Enumeration entChater = chatters.elements();

        while( entChater.hasMoreElements() ) {

            ((IChatClient) entChater.nextElement()).receiveMessage(message);
}
        

        System.out.println("Message from client "+message.name+":\n"+message.text);
}
    
public static void main( String[] args ){

    String downloadLocation = new String("file:C:/Users/mmejiao/Documents/ JCreator%20LE/MyProjects/rmi/");

    String serverURL = new String("///ChatServer"); try {

        System.setProperty("java.rmi.server.codebase", downloadLocation);

        ChatServer server = new ChatServer();

        //Naming.rebind(serverURL, server); //sale error en esta
        //comentando sale 
        //"Chat server ready"

        System.out.println("Chat server ready");
}

    catch(Exception ex){

        ex.printStackTrace();

    }
  }
}