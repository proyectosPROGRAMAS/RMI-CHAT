//================================================================
//C�digo del Servidor (remoto):
//================================================================


package rmi.proyecto01;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;



public class Server implements Hello {


public static int serviciosPrestados;


	public Server() {}


	public String sayHello() {

	return "Hello, borola!";

	}


	public static void main(String args[ ]) {

	String downloadLocation = new String("file:C:/Users/Felipe/Documents/NetBeansProjects/RMI-Proyecto01/");

	try {

		System.setProperty("java.rmi.server.codebase", downloadLocation);

		Server obj = new Server();

		Hello stub = (Hello) UnicastRemoteObject.exportObject(obj,0);

		Registry registry = LocateRegistry.getRegistry();

		//registry.rebind("Hello", stub);  //esta apareciendo error

		System.err.println("Server ready");

		} catch (Exception e) {

		System.err.println("Server exception: " + e.toString());

	e.printStackTrace();

	}
  }
}